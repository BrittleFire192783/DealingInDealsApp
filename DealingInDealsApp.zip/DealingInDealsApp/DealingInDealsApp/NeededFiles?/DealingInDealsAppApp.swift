
//
//  DealingInDealsAppApp.swift
//  DealingInDealsApp
//
//  Created by Ishan Bansal on 9/9/25.
//

import SwiftUI

@main
struct DealingInDealsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
